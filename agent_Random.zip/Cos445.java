import java.io.*;
import java.util.Random;

public class Cos445
{
        public static void main(String[] args) throws java.io.IOException
        {
                BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
                Random random = new Random();
                String dummy=in.readLine();
                while (true)
                {
                        String s = in.readLine();
                        System.out.println(random.nextInt(200));
                }
        }
}

